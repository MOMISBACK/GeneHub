/**
 * Collections components barrel export
 */

export { AddToCollectionButton } from './AddToCollectionButton';
