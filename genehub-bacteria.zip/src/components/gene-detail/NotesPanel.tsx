export type NotesPanelProps = {
  symbol: string;
  organism: string;
  colors: unknown;
  t: unknown;
};

export function NotesPanel(_props: NotesPanelProps) {
  return null;
}
