export { NotesSection } from './NotesSection';
